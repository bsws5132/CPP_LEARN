

#include <iostream>
using namespace std;

int main()
{
	cout << "*" << endl;
	cout << "**" << endl;
	cout << "***" << endl;

	cout << endl;

	cout << "*" << endl;
	cout << "**" << endl;
	cout << "***" << endl;
	cout << "**" << endl;
	cout << "*" << endl;

	cout << "H	H" << endl;
	cout << "H	H" << endl;
	cout << "H	H" << endl;
	cout << "H	H" << endl;
	cout << "HHHHHHHHH" << endl;
	cout << "H	H" << endl;
	cout << "H	H" << endl;
	cout << "H	H" << endl;
	cout << "H	H" << endl;

	cout << false << " " << 'A' << " " << "hello" << endl;
	cout << 23142 << " " << 12897234L << endl;
	cout << 245.78F << 114.782 << " " << 2.051L;

	cout << endl;
	cout << endl;
	cout << endl;
	int x = 4;
	cout << (x * 3) * 5 << endl;
	cout << x * 3 * 5 << endl << endl;
	cout << 12 / (x + 2) << endl;
	cout << 12 / x + 2;


	return 0;
}
